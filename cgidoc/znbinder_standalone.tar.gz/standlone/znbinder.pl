#!/usr/bin/perl
#usage perl znbinder.pl input_file thr
#######################################################################
system "mkdir znbinder_result";
system "perl fasta.pl $ARGV[0] > znbinder_result/fasta_2line_file";
system "perl CHED_extract_1.pl znbinder_result/fasta_2line_file >znbinder_result/CHED_result1.txt";
system " sort -n znbinder_result/CHED_result1.txt  >znbinder_result/CHED_result1_sort.txt";
system "perl CHED_extract_2.pl  znbinder_result/fasta_2line_file >znbinder_result/CHED_result2.txt";
system "perl patgen.pl -i znbinder_result/CHED_result2.txt -w 19 >znbinder_result/CHED_win19.pat";
system "mkdir znbinder_result/PSSM";
system "mkdir znbinder_result/junk";
system "perl run_psiblast.pl znbinder_result/fasta_2line_file";
system "mv  *_pssm  znbinder_result/PSSM/.";
system "mv  *.out  znbinder_result/junk/."; 
system "perl extract_pssm.pl znbinder_result/CHED_win19.pat znbinder_result/fasta_2line_file znbinder_result/pssm_temp  znbinder_result/PSSM  >znbinder_result/CHED_win19.mtx";
system "rm znbinder_result/pssm_temp";
system "cut -d '#' -f2 znbinder_result/CHED_win19.mtx > znbinder_result/CHED_final_win19.mtx";
system "/usr/local/bin/svm_classify  znbinder_result/CHED_final_win19.mtx  level1_model   znbinder_result/svm_score";
system "cut -d ':' -f1 znbinder_result/CHED_win19.pat >znbinder_result/CHED_id";
system "cut -d ':' -f3 znbinder_result/CHED_win19.pat >znbinder_result/CHED_pattern";
system "paste -d ':' znbinder_result/CHED_id  znbinder_result/CHED_pattern >znbinder_result/CHED_id_pattern";
system "paste znbinder_result/CHED_id_pattern  znbinder_result/CHED_result1_sort.txt  znbinder_result/svm_score >znbinder_result/total_result";
open (FH, "znbinder_result/total_result") or die "$!";
open (OUTPUT,">znbinder_result/prediction") or die "$!";
while ($line=<FH>)
{
    chomp ($line);
    @value=split(/\t/,$line);
    @aa=split(/:/,$value[0]);
    $aa[0]=~ s/\>//g;
    @CHED=split(//,$aa[1]);
    $vv = sprintf("%.1f",$value[2]);
    if ($vv >= $ARGV[1])
    {
	print OUTPUT "$aa[0]:$CHED[9]:$value[1]:$vv\n";
    }
    
}
